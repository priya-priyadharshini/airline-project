package com.airline.airline_new.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class PaymentController {

    @GetMapping("/seat-selection")
    public String seatSelectionPage(
            @RequestParam(required = false) Long flightId) {
        return "seat-selection";
    }

    @GetMapping("/payment")
    public String paymentPage(
            @RequestParam(required = false) String seatNumber,
            Model model) {

        model.addAttribute("seatNumber", seatNumber);
        return "payment";
    }

    @PostMapping("/payment-success")
    public String paymentSuccess() {
        return "payment-success";
    }

    @GetMapping("/ticket")
    public String ticketPage(
            @RequestParam(required = false) String seatNumber,
            @RequestParam(required = false) String pnr,
            Model model) {

        model.addAttribute("seatNumber", seatNumber);
        model.addAttribute("pnr", pnr);

        return "ticket";
    }
}