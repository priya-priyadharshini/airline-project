package com.airline.airline_new.controller;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.airline.airline_new.service.FlightService;

@Controller
public class AdminController {

    @Autowired
    private FlightService flightService;

    @GetMapping("/admin-dashboard")
    public String adminDashboard() {
        return "admin-dashboard";
    }

    @GetMapping("/admin-flights")
    public String adminFlights(Model model) {

        try {
            model.addAttribute("flights", flightService.getAllFlights());
        } catch (Exception e) {
            model.addAttribute("flights", Collections.emptyList());
        }

        return "admin-flight";
    }
}