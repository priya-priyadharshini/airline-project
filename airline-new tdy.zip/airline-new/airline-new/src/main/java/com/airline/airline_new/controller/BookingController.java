
package com.airline.airline_new.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BookingController {

    @GetMapping("/book-flight")
    public String bookFlight(@RequestParam Long flightId, Model model) {
        model.addAttribute("flightId", flightId);
        return "seat-selection";
    }
}
